elements = [0]*10;
def array(elements) :
    for i in range(0,10):

        elements[i]=input("Unesi element niza: ");
array(elements);
print("Svaki cetvrti element niza je: ");
for i in range(3,10,4) :
    print("Clan niza: " + elements[i]);
