class Student:
    first_name  = input("Unesite Vase ime: ");
    last_name   = input("Unesite Vase prezime: ");
    index_num   = input("Unesite Vas broj indeksa: ");

object_class = Student();
#Mirko = Student();
#print(Mirko.first_name, Mirko.last_name, Mirko.index_num);
print("Kreirani objekat klase Student je: ");
print(object_class.first_name, object_class.last_name, object_class.index_num);
