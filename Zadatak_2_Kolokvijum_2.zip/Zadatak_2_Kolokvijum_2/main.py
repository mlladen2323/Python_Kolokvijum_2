A = [[1, 2, -1], [3, 6, 7], [5, -4, 2]];
B = [[5, 2], [4, -3], [2, -3]];
print("a) 3. element u 1. redu matrice A je: ", A[0][2]);

print("Prva vrsta matrice B je: ");
for i in range(0, 1):
    for k in range(0, 2):
        print(B[i][k]);

print("Poslednja kolona matrice A je: ");
for i in range(0, 3):
    k = 2;
    print(A[i][k]);

print("Transponovana matrica matrice A: ");
C = [[0, 0, 0], [0, 0, 0], [0, 0, 0]];
for i in range(len(A)):
    for k in range(len(C[0])):
        C[i][k] = C[i][k] + A[i][k];

print(C);

print("Mnozenje matrica A*B: ");
D = [[0, 0], [0, 0], [0, 0]];
for i in range(len(A)):
    for b in range(len(B[0])):
        for c in range(len(B)):
            D[i][b] = D[i][b] + A[i][c] * B[c][b];
print(D);
