import math;

class CPrizma:
   # a = int(input("Unesite stranicu a: "));
   # h = int(input("Unesite visinu H: "));

    def main(self):
        print("----------------- Pravilna trostrana prizma -----------------");
        print("\r\n");


    def povrsina(self, a, h):
        #P = 2⋅a23–√4 + 3 aH
        print("----------------------------------");
        P = (2*(a**2*math.sqrt(3)))/4 + 3*a*h;
        print("Povrsina pravilne trostrane prizme je : " + str(P));

    def zapremina(self, a,h):
        #V=a23–√4⋅H
        print("----------------------------------");
        V = (a**2*math.sqrt(3))/4 * h;
        print("Zapremina pravilne trostrane prizme je : " + str(V));


object_class = CPrizma();
object_class.main();
object_class.povrsina(int(input("Unesite stranicu za izracunavanje povrsine a: ")),int(input("Unesite visinu H: ")));
object_class.zapremina(int(input("Unesite stranicu za izracunavanje zapremine a: ")),int(input("Unesite visinu H: ")));

        # B = (a**2math.sqrt(3))/4;
   # def omotac(self):

   # def povrsina(self) :

   # def zapremina(self):

   # def dijagonala(self):

   # def presek(self):


        # Napisati program koji izračunava površinu, zapreminu, prostornu dijagonalu i poprečni presek
        # prizme koristeći klase (class CPrizma)
#
# B=a23–√4
# M=3aH
# P=2⋅a23–√4+3aH
# V=a23–√4⋅H
# h=a3–√2
#
#
#
#
#
#
# .